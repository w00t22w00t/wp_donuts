</div>
   
    <footer class="footer">

    </footer> 


</main>

<?php wp_footer(); ?>


</body>
</html>